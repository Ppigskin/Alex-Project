#ifndef _INFO_H_
#define _INFO_H_

struct Info{
  int  col,row;
};
#endif

